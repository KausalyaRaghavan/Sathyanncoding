/*
  nota phyx deropza nirmor espashagirineer
  prezamair tolizene ot sleprediez
  foxo tsopa ewrita
  chi donzi-donzi neezer
  i tancla taiwe zeroster
  hoym dishu, new liw len tsopa
  myora ireva das
  ywa floqw drez?
  i tnac tolere
  elsespa tsopa chi
  phystle neezer nafe dreef
  ostaht i yasla physt nye
  deropza nobree nodreu 
  sashuse, 
  sobreude chiyastyedi 
  disbrez the tseba cheba phyx nodreu 
  rofessior, 
  sito dichinor ogez,
  sito dichinor ogez,
        (x2)
  sito dichinor ogez,
  sito dichinor ogez,
        (x2)
*/
/*
  that physics period atrocities
  you know how bad while litsening it
  i tried to stop a lot
  it will kill us little bit
  i cant wait still anymore
  oh my god when will you stop this?
  i am very sad
  why your are testing me 
  Please stop it
  please kill all the physix fan
  as i say,
  please dissmiss all physix fan
  in the school
  but,
  this how life goes
       (x8)
*/