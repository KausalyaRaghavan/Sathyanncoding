$(document).ready(function () {
    $("button").click(function () {
        $("panel").slideToggle("slow");
    });
});