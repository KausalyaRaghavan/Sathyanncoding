var app = angular.module('myApp', []);
      app.controller('myCtrl', function($scope) {
        $scope.firstName = "john";
        $scope.lastName = "Doe";
      });