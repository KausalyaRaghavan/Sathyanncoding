import java.util.Scanner;

public class index {
    public static void main(String[] args) {
        int a,b;
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the first no :");
        a = scanner.nextInt();
        System.out.println("enter the second no :");
        b = scanner.nextInt();
        char num;
        System.out.println("+,-,*,/, or % :");
        num = scanner.next().charAt(0);

        switch(num) {
            case '+':
            System.out.println("a" + "+" + "b" + "=" + (a+b));
            break;
            case '-':
            System.out.println("a" + "-" + "b" + "=" + (a-b));
            break;
            case '*':
            System.out.println("a" + "*" + "b" + "=" + (a*b));
            break;
            case '/':
            System.out.println("a" + "/" + "b" + "=" + (a/b));
            break;
            case '%':
            System.out.println("a" + "%" + "b" + "=" + (a%b));
            break;
            default:
            System.out.println("you entered a incorrect number");
         }
        }
}