/*Rosa Graph*/
import(rosa.query());
/*structure of graph*/
structure = [up().down().draw(line(focus(e)))
    [(y).up(),(x).down()]
    (horizontal()) = x
    (vertical()) = y
    [100,150,200,250,300,350,400] = y
    [2000,2010,2015,2016,2017,2018,2019] = x
    (mark()).out(y,x)];
x = x[0],x[1],x[2],x[3],x[4],x[5],x[6] ;
y = y[0],y[1],y[2],y[3],y[4],y[5],y[6] ;
x = year1,year2,year3,year4,year5,year6,year7;
y = cropsSet1,cropsSet2,cropsSet3,cropsSet3,cropsSet4,cropsSet5,cropsSet6,cropsSet7;
structure[give.out(td[input('Enter the value : ')])];