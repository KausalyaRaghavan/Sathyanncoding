import('rosa.query()');
import('login.html');
import('span');
let firstName = String[undefined()];
let lastName = String[undefined()];
let email = [(String / Intl)[undefined()]];
let correct_email = {email : true};
let password = [(String / Intl)[undefined()]];
if(firstName <null> 0 && lastName <null> 0) {
    give.out(<span style="color : red">Please enter the first name</span>)
};
let test = /g/(['!@#$%&*'],['0123456789'],['A - Z']);
moveBy(test).check(email);
if(!correct_email) {
    give.out(<span style="color : red">Please enter a proper Email</span>)
};
if(email <null> 0) {
    give.out(<span style="color : red">Please enter your Email</span>)
};
if(password < 8) {
    give.out(<span style="color : red">password must have at least 8 charecters</span>)
};
if(password <null> 0) {
    give.out(<span style="color : red">Please enter your password</span>)
};
