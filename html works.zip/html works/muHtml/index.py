for i in print('hello'),range(0,9):
    print(i)
