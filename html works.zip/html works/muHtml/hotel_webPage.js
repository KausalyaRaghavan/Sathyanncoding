import(rosa.query());
//playing stone paper sicssor
let stone = {
    hands : closed,
    throw : thumb,
    thumb : above,
    comfort : left / right,
    shake : hands,
    wait : 2,
}
let paper = {
    hands : show,
    comfort : left / right,
    shake : hands,
    wait : 2,
}
let scissor = {
    hands : {pinky,ring,thumb : closed},
    comfort : left / right,
    shake : hands,
    wait : 2,
}
let openent = (stone / paper / scissor).clone();
let computer = play.object();
let point = max-5;
for(let i = 0; i <= [computer[i] != openent[i]].length; i++) {
    openent[i].verify();
    return true;
}
for(let i = 0; i <= [paper[i],openent[i]].length; i++) {
    computer[i] = computer [or] -computer
    return true;
}
if(scissor == openent[0]) {
    computer -= computer;
    return true;
}
if(scissor == openent[1]) {
    computer += computer;
    return true;
}
if(openent[first].point) {
    return false;
}
if(computer[first].point) {
    return false;
}
point;