function validate() {
  var firstname = document.getElementById("firstname").value;
  var lastname = document.getElementById("lastname").value;
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;
  if(firstname == "") {
      alert("Please enter your First name");
      return false;
  }
  if(lastname == "") {
      alert("Please enter your Last name");
      return false;
  }
  if(email == "") {
     alert("please enter your Email");
     return false;
  }
else {
  var mailformat = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
  var testing = mailformat.test(email);
  if(!testing) {
    alert("please enter a valid email");
    return false;
  }
}

  if(password == "") {
      alert("Please enter your password");
      return false;
  }
  else if(password.length < 8) {
      alert("Password must be have atleast 8 charecters ");
      return false;
  }
  window.location.replace("https://www.irctc.co.in/nget/train-search");
}
 
