document.addEventListener("domcContentLoaded", () => {
    const inputfield = document.getElementById("input");
    inputfield.addEventListener("keydown", (e) => {
        if (e.code === "Enter") {
            let input= inputfield.value;
            inputfield.value="";
            output(input);
        }
    });
});


function output(input) {
    let product;

    //regex remove non word/space chars
    // trim trailing whitespce
    //remove digits- not sure if this is best
    //but solves problem of entering something like 'hi1'

    let text = input.toLowerCase().replace(/[^/w/s]/gi, "").replace(/[\d]/gi, "").trim();
    text=text
    .replace(/ a /g, "") 
    .replace(/ i fell /g, "") 
    .replace(/ whats /g, "what is") 
    .replace(/ please/g, "") 
    .replace(/ please /g, "") 
    .replace(/ r u/g, "are you")
    
    if (compare(prompts, replies, text)) {

        product= compare(prompts, replies, text);  
    }
    else if (text.match(/thank/gi)) {
        product = "your welcome"
    }
    else if (text.match(/(corona|covid|virus)/gi)) {
        product = coronavirus[Math.floor(Math.random() * coronavirus.length)];
    }
    else  {
        product = alternative[Math.floor(Math.random() * coronavirus.length)];
    }


//update dom
    addChat(input, product);
}

   function compare(promptsArray, repliesArray, string) {
       let replay;
       let replayFound = false;
       for (let x=0; x<promptsArray.length; x++){
         for (let y=0; y<promptsArray[x].length; y++) {
             if (promptsArray[x][y] === string) {
                 let replies = repliesArray[x];
                 replay = replies[Math.floor(Math.random() * replies.length)];
                 replayFound = true;
                 break;
             }
         }
       }
       return replay;
   }

   function addChat(input, product) {
       const messegesContainer = document.getElementById("messages");
   }