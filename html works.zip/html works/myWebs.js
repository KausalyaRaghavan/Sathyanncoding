function SwitchImage() {
    var image = document.getElementById('myImage');
    if(image.src.match("C:\Users\LENOVO\Desktop\html works\images\dhoni.jfif")) {
        image.src = "C:\Users\LENOVO\Desktop\html works\images\kholi.gif";
    }
}