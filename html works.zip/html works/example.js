function checkTheFruit() {
    var text;
    var vegtable = document.getElementById("myinput").value;

    //switching the text
    switch(vegtable) {
        case "Ladies finger" :
            text = "i love it.it is my first favorite";
            break;
        case "bitter gaurd" :
            text = "it is my second favorite";
            break;
        case "snake gaurd" :
            text = "ok,i like it ok";
            break;
        case "capcicum" :
            text = "it is my second favorite";
            break;
        case "cabbage" :
            text = "i love it.";
            break;
        default :
        text= "i dont like it.i avoid";
    }
    document.getElementById("demo").innerHTML=text;
}