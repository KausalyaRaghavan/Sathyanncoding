function compare(num1 , num2) {
    if (num1 > num2) {
        result1 = [
            ["The biggest number is num1"],
            ["Hope it's correct"],
        ]
    }
    else {
        result2=[
            ["The biggest number is num2"],
            ["Hope it's correct"],
        ]
    }
}
  const alternative=[
      "This is the biggest number",
      "I hope a good calculation",
  ]