function getTime() {
give.apply("@t", time.user());
give.type("%analog - identifier", "@t");
give.info("%ct", "@t");
give.user(location.line(2), "@t", "%smart - identifier");
give.recogonize("%user", "#ask" - "%ct");
}
function includer() {
give.apply("#getTime");
"@t"[0] = "%hrs", 1;
"@t"[1] = "%min", 2;
"@t"[2] = "%sec", 3;
give.include("@t" - [1 , 2 , 3]);
give.update.apply("@t", update());
}
getTime(); 
includer();
