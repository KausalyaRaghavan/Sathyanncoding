import turtle
win = turtle.Screen()
win.setup(800,600)
win.bgcolor("blue")
win.title("Pong game")
win.tracer(0)

#left_box
leftbox = turtle.Turtle()
leftbox.speed(0)
leftbox.shape("square")
leftbox.color("white")
leftbox.shapesize(stretch_wid=5,stretch_len=1)
leftbox.penup()
leftbox.goto(-380,0)

#right_box
rightbox = turtle.Turtle()
rightbox.speed(0)
rightbox.shape("square")
rightbox.color("white")
rightbox.shapesize(stretch_wid=5,stretch_len=1)
rightbox.penup()
rightbox.goto(380,0)

#ball
ball = turtle.Turtle()
ball.speed(0)
ball.shape("circle")
ball.color("white")
ball.dx = 0.05
ball.dy = 0.15
ball.penup()
#moving boxes

def leftbox_up():
    leftbox.sety(leftbox.ycor() + 20)
def leftbox_down():
    leftbox.sety(leftbox.ycor() - 20)
def rightbox_up():
    rightbox.sety(rightbox.ycor() + 20)
def rightbox_down():
    rightbox.sety(rightbox.ycor() - 20)
win.listen()
win.onkeypress(leftbox_up,'a')
win.onkeypress(leftbox_down,'s')
win.onkeypress(rightbox_up,'d')
win.onkeypress(rightbox_down,'f')

while True:
 win.update()
 #ball movement
 ball.setx(ball.xcor() + ball.dx)
 ball.sety(ball.ycor() + ball.dy)
 
 #topwall
 if(ball.ycor() > 290):
     ball.sety(290)
     ball.dy *= -1
 #bottom wall
 if(ball.ycor() < -290):
     ball.sety(-290)
     ball.dy *= -1
 #right wall
 if(ball.xcor() > 390):
     ball.setx(390)
     ball.dx *= -1
 #left wall
 if(ball.xcor() < -390):
     ball.setx(-390)
     ball.dx *= -1
 #collide with boxes
 if(ball.xcor() > 370 and rightbox.ycor() - 50 < ball.ycor()  < rightbox.ycor() + 50):
     ball.setx(360)
     ball.dx *= 1
 if(ball.xcor() < -370 and leftbox.ycor() - 50 < ball.ycor() < leftbox.ycor() + 50):
     ball.setx(-360)
     ball.dx *= -1