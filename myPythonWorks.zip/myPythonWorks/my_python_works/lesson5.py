#string operations in python




str = 'hello world'
print(str[0:5])

data = 'hello john, I got the new audi car'

print(data[6:10])

print(data[26:])


str = 'hello world'
print(str)
print(str[0])
print(str[2:5])
print(str[2:])
print(str * 3)
print(str + ' TEST')



#Looping through a string
data = 'hello john, i got new audi car'
for x in data:
    print(x)
    
#check string
txt = 'the best things in the life are not free'
if "free" in txt:
    print('yes , "free" is present')
    
#check if not
txt = 'the best things in the life are not free'
print("expensive" not in txt)

#replace the word
txt = 'one one was a race horse, two two was one too. '
x = txt.replace("one", "three")
print(x)

#Finding the index
txt = 'hello, welcome to my world'

x = txt.index('welcome')
print(x)

#slicing in b/w the length
x = txt.index("c",7,14)
print(x)