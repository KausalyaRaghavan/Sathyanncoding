
x = range(1,4)
y = range(1,6)
for i in x:
    for j in y:
        print(j, end='')
    print('')