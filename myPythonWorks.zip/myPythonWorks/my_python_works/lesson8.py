# Python operators

'''
  Python classify the operators in the following groups:
  
  1.arithmetic operators
  2.assignment operators
  3.comparison operators
  4.Logical operators
  5.Identity operators
  6.Memership operators
  7.bitwise operators
'''
#1. Arithmetic operators -> Addition , subtraction , Multiplication, Division
# Moduls, Exponential , Floor division

#1. Addition
mark1 = 90
mark2 = 80

Total_marks = mark1 + mark2
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n Total is {Total_marks}')

#Task :-

#2. subtraction
mark1 = 20
mark2 = 10
sub = mark1 - mark2
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n Subtraction is {sub}')

#3. Multiplication
mul = mark1 * mark2
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n multiplication is {mul}')

#4. division
div = mark1 / mark2
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n division is {div}')

#5. module
module = mark1 % mark1
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n module is {module}')

#6. exponent
exp = mark1 ** mark2
print(f'Mark1 {mark1} ,\n Mark2 {mark2}\n Exponent is {exp}')

#Floor division -> // , it will return the result dwon to
# the nearest whole number

data1 = 15
data2 = 2

result = data1 // data2
print(f'floor division of {data1} with {data2} is : {result}')

#2. Assignment operators
#2.1 - Single Equal operators (=)
#Example

mark1 = 87
mark2 = 96

print(f'Total mark is{mark1 + mark2}')

# += operator
mark1 += mark2 #mark1 = mark1 + 30
print(f'Mark 1 after adding marks is{mark1}')

# -= operator
mark2 -= 30 #mark2 = mark2 - 30
print(f'Mark2 after mins mark is{mark2}')

# *= operator

mark1 *= 2
print(f'Mark1 after multiplying 2 is: {mark1}')

# /= operator

mark2 /= 3
print(f'mark 2 after dividing bu 3 is: {mark2}')

# %= operator

mark1 %= 3
print(f'Mark1 after remainder value is 3 is:{mark1}')

# //= operator

mark2 //= 2
print(f'Mark2 after floor division value is: {mark2}')

# **= operator

mark1 **= 2
print(f'Mark1 after exponent value is : {mark1}')