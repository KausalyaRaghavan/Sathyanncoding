#Task given by sir

for i in range(5,75):
    if(i%2 == 0):
        print(i)

#task 2 given by sir

for i in range(50,100):
    if(i%2 == 1):
     print(i)
     
#dict task given by sir

Sample_data =  {'item1': 45.50, 'item2':35, 'item3': 41.30, 'item4':55, 'item5': 24}
x = list(Sample_data.keys())[0]
y = list(Sample_data.keys())[1]
z = list(Sample_data.keys())[2]
a = list(Sample_data.keys())[3]
b = list(Sample_data.keys())[4]

m = input('enter the item:')
if(m == x):
    print(Sample_data['item1'])
if(m == y):
    print(Sample_data['item2'])
if(m == z):
    print(Sample_data['item3'])
if(m == a):
    print(Sample_data['item4'])
else:
    print(Sample_data['item5'])






