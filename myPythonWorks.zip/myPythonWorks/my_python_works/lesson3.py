# Python Data Types

# Varibales can store data of different 
# types and different types can perform 
# different task.

'''
Built-in Data Types

Text Type - str
Number Type - int,float,complex
Sequence Type - list,tuple,range

Mapping Type - dict
Set Type - set,frozenset
Boolean Type - bool
Binary Type - bytes,bytearray, memoryview
None Type - NoneType

'''

# String Type

name ="DMCJ Academy"
print("\n Name : " + name)
print("\n Name Type is ")
print(type(name))

# integer type
age = 35
print(f"\n Your Age is {age}")
print("\n Age Type is ")
print(type(age))

# Float Type
height = 5.5
print(f"\n Your Height is {height} ")
print("\n Height Type is ")
print(type(height))

# Complex Type
data1 = 1j
print(f"\n data 1 value is {data1} ")
print("\n data 1 Type is ")
print(type(data1))



# List Data Type
fruitlist = ["apple","banana","cherry"]
print(fruitlist)

fruitlist[2] = "Watermelon"
print("After Adding Watermelon")
print(fruitlist)

print("\n Fruitlist Type is ")
print(type(fruitlist))

# Tuple Data Type -> Can not modify 
# existing data
carlist = ("Hyundai","BMW","Audi")
print(carlist)

#carlist[2] = "Benz"
#print("After Adding Benz in carlist")
#print(carlist)

print("\n Car List Type is ")
print(type(carlist))


# Range data type

data2 = range(10)
print(data2)
print("\n Data type of range is ")
print(type(data2))

#loop through range
for i in range(10):
    print(i)

#define the start and stop in range
for i in range(5,25):
    print(i)

#define the start, stop and steps in range
for i in range(5,25,2):
    print(i)

# Task 

# write a python program to display the number which is divisable by 2 from the range 5 to 75
#  if  i%2 == 0 :
#    print(i)


# print odd numbers using range from 50 to 100

n=5

for i in range(n):
    for j in range(i):
        print ('* ', end="")
    print('')

for i in range(n,0,-1):
    for j in range(i):
        print('* ', end="")
    print('')












# Dict Data type

student_details ={"Name" : "John", "Age" :20, "Email":"john@gmail.com"}
print(student_details)
print("\n Student Detail Data Type is ")
print(type(student_details))

print(f"\n Name is { student_details['Name'] } ")
print(f"\n Age is { student_details['Age'] } ")
print(f"\n Email is { student_details['Email'] } ")



# Set Data Type - unorderd item - Automatically remove the duplicate
employee_list ={"John","Sam","Vicky","Joe","Vicky"}
print(employee_list)
print("\n Employee Detail Data Type is ")
print(type(employee_list))

#frozenset Data Type
fruit_list = frozenset({"apple", "banana", "cherry"})
print(fruit_list)
print("\n fruit list Data Type is ")
print(type(fruit_list))

# bool Data Type
data_received = True
print(f"Data Received : {data_received}")
print("\n data received Data Type is ")
print(type(data_received))

# bytes Data Type
byte_data = b"Welcome"
print(f"Byte Data is : {byte_data}")
print("\n byte data Data Type is ")
print(type(byte_data))

# bytearray Data Type
byte_array = bytearray(10)
print(f"Byte Array Value is : {byte_array}")
print("\n byte array Data Type is ")
print(type(byte_array))

# memoryview Data Type
memory_view = memoryview(bytes(10))
print(f"memory view Value is : {memory_view}")
print("\n memoryview Data Type is ")
print(type(memory_view))

#None Data Type
received_data = None
print(f"Received Data value is : {received_data}")
print("\n received data - Data Type is ")
print(type(received_data))

received_data = 123456
if(received_data != None):
    print(f"Received Data is : {received_data}")

'''
None is not the same as False.
None is not 0.
None is not an empty string.
Comparing None to anything will always return False except None itself.

Note : The None keyword is used to define a null variable or an object. 
In Python, None keyword is an object, and it is a data type of the class NoneType.

'''



