val1 = input('Enter the value 1')
val2 = input('Enter the value 2')

add = int(val1) + int(val2)
sub = int(val1) - int(val2)
mul = int(val1) * int(val2)
div = int(val1) / int(val2)

print(f'value of addition is {add}')
print(f'value of subtraction is {sub}')
print(f'value of multiplication  is {mul}')
print(f'value of division is {div}')

