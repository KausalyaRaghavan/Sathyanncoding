#python casting

'''
Type casting is the method to convert the variable data type into a 
certain data type in order to the operation required to be performed
by users.

There are two types of type casting in python :
1.implict type casting 
2. Explicit type casting
'''

#Example

mark1 = '59'
mark2 = '65'

print(f'Mark1 type is {type(mark1)}')
print(f'Mark2 type is {type(mark2)}')

print(f'Total = {int(mark1) + int(mark2)}')

#example 2

#python automatically converts a to int
a = 7
print(type(a))

#python automatically convert b to float
b = 3.0
print(type(b))

# Python automatically converts c to float as it is a float addition
c = a + b
print(c)
print(type(c))

# Python automatically converts d to float as it is a float multiplication
d = a * b
print(d)
print(type(d))

#string variables
a = '5.9'

# typecast float
n = float(a)

print(n)
print(type(n))
mark1 = input('please enter your mark 1 \n')
mark2 = input('please enter your mark 2 \n')

total = int(mark1) + int(mark2)

print(f'Total = {total}')
