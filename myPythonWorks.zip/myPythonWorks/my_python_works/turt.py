from re import T
print(T)