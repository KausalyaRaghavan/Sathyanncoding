
from msilib.schema import Error


class error(Exception):
    pass
class toosmallno(error):
    pass
class toolargeno(error):
    pass
num = 10
while True:
    try:
        ch = int(input('enter the number:'))
        if(ch>10):
            raise toolargeno
        if(ch<10):
            raise toosmallno
        break
    except toosmallno:
        print('you entered too small number')
    except toolargeno:
        print('you entered too large number')
print('you entered correct number')