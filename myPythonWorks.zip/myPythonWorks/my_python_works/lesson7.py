'''
 Boolean
 equal, not equal, greater than, lessar than
 
 You can evaluate any expression in python, and get one of 2 answers. True / False
''' 
#Example:-

mark1 = 89
mark2 = 95

if(mark1 > mark2):
    print(f'Mark1t {mark1} is > Mark2 {mark2}')
else:
    print(f'Mark2 {mark2} is > Mark2 {mark1}')
print(mark1 > mark2)

mark3 = 97
mark1 = 89

#Equal (==):-
if(mark3 == 97):
    print('its equal')
#Not equal (!=)
if(mark1 != mark3):
    print('Mark1 is not equal to mark3')
# Greatert than (>)
if(mark3 > mark1):
    print('mark3 > mark1')
#Lessar than (<)
if(mark3 < mark1):
    print('mark1 > mark3')
    
'''
 bool() parameter
 The Bool() method takes in a single parameter
 argument - whose bolean value is returned
 
 bool() Return Value
 The bool() method returns:-
 
 False - if argument is empty, False, o / none
 True - if argument is any number (besides 0), True or a String
'''

#recieved_data = ""
data_recieved = 1 #len(recieved_data)
print(f'Data is recieved { bool(data_recieved)}')

name = input('Please enter your name : \n')

if(bool(name)):
    print(f'\n Welcome to our group Mr/Mrs : {name}')
else:
    print('You have not entered your name ')
    
score = input('\n Please enter your score out of 100 to check your grade')
score_value = int(score) # converting score to integer

if(bool(score_value)):
    if(score_value > 50 and score_value < 70):
        print('\n you are grade "c"')
    elif(score_value > 70 and score_value < 90):
        print('\n You are Grade "B"')
    elif(score_value >= 90):
        print('\n You are Grade "A"')
    else:
        print('\n You are failed')
else:
    print('You have entered zero value')
    
#