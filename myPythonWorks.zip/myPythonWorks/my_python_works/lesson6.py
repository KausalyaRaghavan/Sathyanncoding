#Python Escape charecters
'''
an escape charecters is a back slash '\'
 followed by a charecter you want to insert in it

 txt = 'we are so-called "vikings" from north.'
  Above declaration raise error due to inner doublr quote not allowed
 inside of any sentences
to fix the issue, otaras the proble
'''
import string

txt = "we are so-called \"vikings\" from north"
print(txt)

# other escaping charecters

#1. Single quote
txt1 = 'It\'s all right'
print(txt1)

# 2. backslash
txt2 = 'what is {9} \ {3} ?'
print(txt2)

# 3. New line
txt3 = 'hello \n world'
print(txt3)

# 4. carriage return

txt4 = 'hello \n\r World'
print(txt4)

'''
 a carriage return would exactly that, return the print head carriage
 to the begining of the line
 
 a newline charecter would simple shift the roller to the next line
 without moving the print head
'''
string = 'my website is lactracal \r Solution'
print(string)

string = 'my website is lactracal \n\r Solution'
print(string)

string = 'my website is lactracal \r Solution'
print(string)

#5.Tab
txt5 = 'Hello \t World!!'
print(txt5)

#6.backspace
#This example erases one charecter (backspace):
txt6 = 'Hello \b World!!'
print(txt6)

#7. octal value
# A backslash followed by three integers will result in a octal value
txt7 = '\110\145\154\154\157'
print(txt7)

# 8. Hex value

#A backslash followed by an 'x' and a hex number represents a hex value:
txt8 = "\x48\x49"
print(txt8)

colors = ['red', 'green', 'blue']
#s = f'The RGB colors are:\n {'\n'.join(colors)}'
#print(s)

# above arror is due to f-string cannot contain a backslash charecter as a part
# of the expression inside the curly braces {}.
# To fix the error 

color = ['red', 'green', 'blue']
rgb = '\n'.join(colors)
s = f'The RGB colors are:\n{rgb}'
print(s)