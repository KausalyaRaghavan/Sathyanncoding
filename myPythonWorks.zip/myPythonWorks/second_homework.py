#Declaring variables for student list
student_list = ["John","Section A",55,67,45,66,77,89]
name,section,role1,role2,role3,role4,role5,role6 = student_list

#printing the name
print(name)

#printing the student section
print(section)

#printing the total mark
x = role1+role2+role3+role4+role5+role6
print(x)

#printing the average
y = (role1+role2+role3+role4+role5+role6)/6
print(y)